import {Component} from '@angular/core';

@Component({
	
	selector:'<my-component></my-component>',
	templateUrl:'./app.employeecomponent.html'
	
	//{{}} = intercollation // one way binding
	
})

export class AppEmployeeComponent
{
	/*empId:number = 1001;
	isDisabled:string='true';*/
	
	empId:number=null;
	empName:string=null;
	empSalary:number=null;
	empDepartment:string=null;
	onClick():void{
		console.log('Welcome to Event');
		alert(this.empId +this.empName +this.empSalary +this.empDepartment);
	}
	
}  