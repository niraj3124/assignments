"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var AppComponent = (function () {
    function AppComponent() {
        this.search = '';
        this.employees = [
            {
                id: 1,
                title: "Android for Expert",
                year: 1996,
                author: "George R. R"
            },
            {
                id: 2,
                title: "Complete Reference",
                year: 1998,
                author: "George P. R. Martin"
            },
            {
                id: 3,
                title: "BackBone JS",
                year: 2000,
                author: "Kalvin R.V"
            },
            {
                id: 4,
                title: "Knock Out JS",
                year: 2005,
                author: "J.J Markin"
            },
            {
                id: 5,
                title: "Pointer in C",
                year: 2011,
                author: "Y P Kanitkar"
            },
            {
                id: 6,
                title: "Big Data",
                year: 2011,
                author: "Pearson D A"
            },
            {
                id: 7,
                title: "A Dream of Spring",
                year: 2012,
                author: "George R. R. Martin"
            },
            {
                id: 8,
                title: "The Philosopher's Stone",
                year: 1997,
                author: "J. K. Rowling"
            },
            {
                id: 9,
                title: "The Chamber of Secrets",
                year: 1998,
                author: "J. K. Rowling"
            },
            {
                id: 10,
                title: "The Prisoner of Azkaban",
                year: 1999,
                author: "J. K. Rowling"
            }
        ];
    }
    return AppComponent;
}());
AppComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        templateUrl: './app.component.html'
    })
], AppComponent);
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map