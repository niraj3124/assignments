export interface Employee
{
	id:number,
	title:string,
	year:number,
	author:string;
}