export interface IEmployee
{
	id:number,
	title:string,
	year:number,
	author:string;
	
}