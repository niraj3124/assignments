export class Employee
{
	
	empId:number;
	empName:string;
	empSalary:number;
	empDept:string;
	
}
