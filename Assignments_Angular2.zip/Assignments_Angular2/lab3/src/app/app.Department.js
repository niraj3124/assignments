"use strict";
var Department = (function () {
    function Department() {
    }
    return Department;
}());
exports.Department = Department;
//# sourceMappingURL=app.Department.js.map