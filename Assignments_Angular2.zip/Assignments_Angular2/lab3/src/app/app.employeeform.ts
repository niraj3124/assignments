import {Component} from '@angular/core';
import  { NgForm }  from "@angular/Forms/forms";
import  {Department}from "./app.Department";
import  {Employee} from "./app.employee";

@Component({
	selector:'emp-app',
	templateUrl:'./app.employee.html'
})
export class EmployeeComponent{
	emp:Employee={
		eId:null,
		eName:null,
		eSalary:null,
		eType:null,
		eDepartment:null,
		eskill:null
	};
	departments :Department[]=[
	{dId:1,dName:"java"},
	{dId:2,dName:".net"},
	{dId:3,dName:"BI"},
	{dId:4,dName:"java"},
	];
	
	getData(empForm:NgForm):void{
		console.log(empForm.value);
	}
}